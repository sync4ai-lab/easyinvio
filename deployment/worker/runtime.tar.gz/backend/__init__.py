"""EasyInvio logistics extensions."""
